/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.eci.arsw.blacklistvalidator;

import edu.eci.arsw.spamkeywordsdatasource.HostBlacklistsDataSourceFacade;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author hcadavid
 * @author juan pablo caballero
 * @author robinson nuñez
 */

public class HostBlackListsValidator {

    private static final int BLACK_LIST_ALARM_COUNT = 5;
    

    /**
     * Check the given host's IP address in all the available black lists,
     * and report it as NOT Trustworthy when such IP was reported in at least
     * BLACK_LIST_ALARM_COUNT lists, or as Trustworthy in any other case.
     * The search is not exhaustive: When the number of occurrences is equal to
     * BLACK_LIST_ALARM_COUNT, the search is finished, the host reported as
     * NOT Trustworthy, and the list of the five blacklists returned.
     * @param ipaddress suspicious host's IP address.
     * @param N number of threads to use in the search.
     * @return  Blacklists numbers where the given host's IP address was found.
     */
    public List<Integer> checkHost(String ipaddress, int N) {

        LinkedList<Integer> blackListOcurrences = new LinkedList<>();

        HostBlacklistsDataSourceFacade skds = HostBlacklistsDataSourceFacade.getInstance();

        int totalServers = skds.getRegisteredServersCount();

        if (N <= 0) N = 1;
        if (N > totalServers) N = totalServers;

        int segmentSize = totalServers / N;

        AtomicInteger foundReports = new AtomicInteger(0);

        List<BlackListSearchThread> threads = new LinkedList<>();

        for (int i = 0; i < N; i++) {
            int start = i * segmentSize;
            int end = (i == N - 1) 
                    ? totalServers 
                    : start + segmentSize;
            threads.add(new BlackListSearchThread(start, end, ipaddress, foundReports, BLACK_LIST_ALARM_COUNT));
        }

        for (BlackListSearchThread thread : threads) {
            thread.start();
        }

        for (BlackListSearchThread t : threads) {
            try {
                t.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                LOG.log(Level.WARNING, "Main thread interrupted while waiting for search threads");
                for (BlackListSearchThread remaining : threads) {
                    if (remaining.isAlive()) {
                        remaining.interrupt();
                    }
                }
                break;
            }
        }

        int ocurrencesCount = 0;
        int checkedListsCount = 0;

        for (BlackListSearchThread t : threads) {
            blackListOcurrences.addAll(t.getOccurrences());
            ocurrencesCount += t.getOccurrences().size();
            checkedListsCount += t.getCount();
        }

        if (ocurrencesCount >= BLACK_LIST_ALARM_COUNT) {
            skds.reportAsNotTrustworthy(ipaddress);
        } else {
            skds.reportAsTrustworthy(ipaddress);
        }

        LOG.log(Level.INFO, 
            "Checked Black Lists:{0} of {1}",
             new Object[]{checkedListsCount, totalServers});

        LOG.log(Level.INFO, 
            "Found reports total: {0}", foundReports.get());

        return blackListOcurrences;
    }

    private static final Logger LOG = Logger.getLogger(HostBlackListsValidator.class.getName());
}
