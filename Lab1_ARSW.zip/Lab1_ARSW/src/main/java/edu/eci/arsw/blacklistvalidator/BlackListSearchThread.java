package edu.eci.arsw.blacklistvalidator;

import edu.eci.arsw.spamkeywordsdatasource.HostBlacklistsDataSourceFacade;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

@Getter
@RequiredArgsConstructor
public class BlackListSearchThread extends Thread {
    private static final Logger LOG = Logger.getLogger(BlackListSearchThread.class.getName());
    
    private final int start;
    private final int end;
    private final String ip;
    private final List<Integer> occurrences = new ArrayList<>();
    private int count = 0;

    private final AtomicInteger foundReports;
    private final int reportLimit;

    @Override
    public void run() {
        HostBlacklistsDataSourceFacade skds = HostBlacklistsDataSourceFacade.getInstance();

        for (int k = start; k < end; k++) {
            if (foundReports.get() >= reportLimit || Thread.currentThread().isInterrupted()) {
                break;
            }
            count++;
            try {
                if (skds.isInBlackListServer(k, ip)) {
                    occurrences.add(k);
                    int current = foundReports.incrementAndGet();
                    if (current >= reportLimit) {
                        break;
                    }
                }
            } catch (RuntimeException re) {
                LOG.log(Level.WARNING, 
                    "Error checking blacklist server {0} for IP {1}: {2}", 
                    new Object[]{k, ip, re.getMessage()});
            }
        }
    }
}